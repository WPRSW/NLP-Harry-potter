import spacy
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB



nlp = spacy.load('en_core_web_sm')
nlp.max_length = 1500000  # maximum length limit

def extract_character_names(file_paths):
    character_names = set()
    for file_path in file_paths:
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()
            if len(text) > nlp.max_length:
                for i in range(0, len(text), nlp.max_length):
                    chunk = text[i:i + nlp.max_length]
                    doc = nlp(chunk)
                    for ent in doc.ents:
                        if ent.label_ == 'PERSON':
                            character_names.add(ent.text)
            else:
                doc = nlp(text)
                for ent in doc.ents:
                    if ent.label_ == 'PERSON':
                        character_names.add(ent.text)
    return list(character_names)



book_files = [
    # '01 Harry Potter and the Sorcerers Stone.txt',
    # '02 Harry Potter and the Chamber of Secrets.txt',
    # '03 Harry Potter and the Prisoner of Azkaban.txt',
    # '04 Harry Potter and the Goblet of Fire.txt',
    '05 Harry Potter and the Order of the Phoenix.txt',
    # '06 Harry Potter and the Half-Blood Prince.txt',
    # '07 Harry Potter and the Deathly Hallows.txt'
]


character_names = extract_character_names(book_files)



data = {
    'Name': [
        'Harry Potter', 'Hermione Granger', 'Draco Malfoy',
        'Luna Lovegood', 'Cedric Diggory', 'Severus Snape',
        'Cho Chang', 'Neville Longbottom', 'Bellatrix Lestrange'
    ],
    'House': [
        'Gryffindor', 'Hufflepuff', 'Slytherin',
        'Ravenclaw', 'Hufflepuff', 'Slytherin',
        'Ravenclaw', 'Slytherin', 'Gryffindor'
    ]
}



df = pd.DataFrame(data)


X = df['Name']
y = df['House']

vectorizer = CountVectorizer()
X_vectorized = vectorizer.fit_transform(X)


X_train, X_test, y_train, y_test = train_test_split(X_vectorized, y, test_size=0.2, random_state=42)



classifier = MultinomialNB()
classifier.fit(X_train, y_train)


def predict_house(character_name):
    character_name_vectorized = vectorizer.transform([character_name])
    prediction = classifier.predict(character_name_vectorized)
    return prediction[0]

for character_name in character_names:
    predicted_house = predict_house(character_name)
    print(f"The predicted house for {character_name} is: {predicted_house}")
